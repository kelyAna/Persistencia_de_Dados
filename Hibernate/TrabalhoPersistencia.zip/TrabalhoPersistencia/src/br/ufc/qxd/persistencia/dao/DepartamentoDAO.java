package br.ufc.qxd.persistencia.dao;

import java.util.List;

import br.ufc.qxd.persistencia.model.Departamento;

public interface DepartamentoDAO extends GenericDAO<Departamento>{
	
}
