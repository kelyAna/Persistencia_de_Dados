package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.Pesquisador;

public interface PesquisadorDAO extends GenericDAO<Pesquisador>{
	
}
