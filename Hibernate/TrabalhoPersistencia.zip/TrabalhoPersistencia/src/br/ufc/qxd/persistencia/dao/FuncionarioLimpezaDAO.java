package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.FuncionarioLimpeza;

public interface FuncionarioLimpezaDAO extends GenericDAO<FuncionarioLimpeza>{

}
