package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.Funcionario;

public interface FuncionarioDAO extends GenericDAO<Funcionario>{

}
