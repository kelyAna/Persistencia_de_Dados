package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.Secretario;

public interface SecretarioDAO extends GenericDAO<Secretario>{

}
