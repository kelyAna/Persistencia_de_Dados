package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.Endereco;

public interface EnderecoDAO extends GenericDAO<Endereco>{

}
