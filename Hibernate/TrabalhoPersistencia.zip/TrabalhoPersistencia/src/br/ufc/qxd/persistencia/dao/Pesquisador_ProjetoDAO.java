package br.ufc.qxd.persistencia.dao;

import br.ufc.qxd.persistencia.model.Pesquisador_Projeto;

public interface Pesquisador_ProjetoDAO extends GenericDAO<Pesquisador_Projeto>{

}
